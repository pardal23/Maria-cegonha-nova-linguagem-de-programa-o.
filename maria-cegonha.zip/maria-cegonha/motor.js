/**
 * MOTOR CEGONHA 2026 - Versão com IF, ELSE, WHILE
 */
function executarCegonhaEngine(html) {
    return html.replace(/<cegonha>([\s\S]*?)<\/cegonha>/g, function (_, codigo) {
        let vars = {};
        let saida = "";

        // Função para resolver expressões matemáticas e variáveis
        function resolver(expr) {
            let resolvida = expr;
            for (let v in vars) {
                const regex = new RegExp("\\b" + v + "\\b", "g");
                resolvida = resolvida.replace(regex, vars[v]);
            }
            try {
                return new Function("return (" + resolvida + ")")();
            } catch { return expr; }
        }

        // Limpeza básica de comentários e espaços
        let linhas = codigo.split(/\r?\n/).map(l => l.trim()).filter(l => l !== "" && !l.startsWith("#"));
        let i = 0;

        while (i < linhas.length) {
            let linha = linhas[i];

            // 1. IF / SENAO (se / senao)
            if (linha.startsWith("se ")) {
                let condicao = linha.match(/\((.*)\)/)[1];
                let blocoIf = [];
                i++;
                while (i < linhas.length && !linhas[i].startsWith("}")) {
                    blocoIf.push(linhas[i]);
                    i++;
                }
                
                let executouIf = false;
                if (resolver(condicao)) {
                    processarBloco(blocoIf);
                    executouIf = true;
                }
                
                i++; // Pula o "}"
                if (i < linhas.length && linhas[i].startsWith("senao")) {
                    i++; // Pula o "senao {"
                    let blocoElse = [];
                    while (i < linhas.length && !linhas[i].startsWith("}")) {
                        blocoElse.push(linhas[i]);
                        i++;
                    }
                    if (!executouIf) processarBloco(blocoElse);
                    i++; // Pula o "}"
                }
                continue;
            }

            // 2. WHILE (enquanto)
            if (linha.startsWith("enquanto ")) {
                let condicao = linha.match(/\((.*)\)/)[1];
                let blocoWhile = [];
                let inicioWhile = i;
                i++;
                while (i < linhas.length && !linhas[i].startsWith("}")) {
                    blocoWhile.push(linhas[i]);
                    i++;
                }
                
                let seguranca = 0;
                while (resolver(condicao) && seguranca < 100) {
                    processarBloco(blocoWhile);
                    seguranca++;
                }
                i++; 
                continue;
            }

            // 3. ATRIBUIÇÃO E CEGONHA()
            processarComando(linha);
            i++;
        }

        function processarBloco(listaLinhas) {
            listaLinhas.forEach(l => processarComando(l));
        }

        function processarComando(l) {
            if (l.includes("=")) {
                let [nome, valor] = l.split("=").map(s => s.trim());
                vars[nome] = resolver(valor);
            } else if (l.startsWith("cegonha(")) {
                let conteudo = l.replace(/^cegonha\s*\(|\)$/g, "").trim();
                if ((conteudo.startsWith('"') || conteudo.startsWith("'"))) {
                    saida += conteudo.slice(1, -1);
                } else {
                    saida += resolver(conteudo);
                }
            }
        }

        return `<div class="cegonha-output">${saida}</div>`;
    });
}

window.addEventListener("load", () => {
    document.querySelectorAll("div[id^='conteudo']").forEach(div => {
        div.innerHTML = executarCegonhaEngine(div.innerHTML);
    });
});